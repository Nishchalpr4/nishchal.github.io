import './globals.css'
export const metadata = { title: 'Nishchal PR — Portfolio', description: 'ECE undergrad & software developer' }
export default function RootLayout({ children }){ return (<html lang="en"><body>{children}</body></html>)}
